# notification-runtime-permission

<div align="center">
    <img src="screenshots/android-13-notification-runtime-permission.png" />
</div>

This application demonstrates Android 13's new feature: [Notification Runtime Permission](https://developer.android.com/about/versions/13/changes/notification-permission).
