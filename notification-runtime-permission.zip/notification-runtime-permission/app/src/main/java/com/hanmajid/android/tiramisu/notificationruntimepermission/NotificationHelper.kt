package com.hanmajid.android.tiramisu.notificationruntimepermission

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.navigation.NavDeepLinkBuilder

@RequiresApi(Build.VERSION_CODES.O)
fun createNotificationChannel(context: Context) {
    val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val channel = NotificationChannel(
        MainActivity.CHANNEL_ID,
        "Important Notification Channel",
        NotificationManager.IMPORTANCE_HIGH,
    ).apply {
        description = "This notification contains important announcement, etc."
    }
    notificationManager.createNotificationChannel(channel)
}

@RequiresApi(Build.VERSION_CODES.O)
fun sendNotification(context: Context, pendingIntent: PendingIntent, title: String, textContext: String) {
    val builder = NotificationCompat.Builder(context, MainActivity.CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_launcher_foreground)
        .setContentTitle(title)
        .setContentText(textContext)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setContentIntent(pendingIntent)
        .setAutoCancel(true)

    with(NotificationManagerCompat.from(context)) {
        notify(getUniqueId(), builder.build())
    }
}

private fun getUniqueId() = (System.currentTimeMillis()%10000).toInt()